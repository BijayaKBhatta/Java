package com.example.model;

public class Course {
	String name;
	String description;

}
