package com.example.model;

public class Gpa {
	String letterGrade;
	String gpaValue;
	public String getLetterGrade() {
		return letterGrade;
	}
	public void setLetterGrade(String letterGrade) {
		this.letterGrade = letterGrade;
	}
	public String getGpaValue() {
		return gpaValue;
	}
	public void setGpaValue(String gpaValue) {
		this.gpaValue = gpaValue;
	}
	

}
