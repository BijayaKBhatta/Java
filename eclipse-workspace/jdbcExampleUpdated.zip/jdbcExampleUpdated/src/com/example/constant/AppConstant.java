package com.example.constant;

public class AppConstant {
	public static String GETRESULT = "SELECT * FROM RESULT";

}
