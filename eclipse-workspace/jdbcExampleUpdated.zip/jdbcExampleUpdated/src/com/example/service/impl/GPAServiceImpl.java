package com.example.service.impl;

import com.example.model.Gpa;
import com.example.service.GPAService;

public class GPAServiceImpl implements GPAService {

	@Override
	public Gpa getGPA() {
		//REsult and GPA
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Gpa getClassGPA() {
		// TODO Auto-generated method stub
		return null;
	}

}
